# PointOfSale
The point of sale (POS) or point of purchase (POP) is the time and place where a retail transaction is completed. 
At the point of sale, the merchant calculates the amount owed by the customer, indicates that amount, may prepare 
an invoice for the customer (which may be a cash register printout), and indicates the options for the customer to make payment.

Follow the steps:- 
Step 1:- Download the repository
Step 2:- Compile MENDOZA_ELGA.java file
Step 3:- User Id- chandigarhuniversity
Step 4:- Password- 15bcs1402

